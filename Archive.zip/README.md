# Barber | Alexander "DaBarber" Tapia

This is a landing page for a celebrity barber who deals with NFL Clients.
